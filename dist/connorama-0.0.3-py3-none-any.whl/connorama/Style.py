RESET_ALL        = "\033[0m"

bold             = "\033[1m"
dim              = "\033[2m"
underlined       = "\033[4m"
reverse          = "\033[7m"
hidden           = "\033[8m"

RESET_bold       = "\033[21m"
RESET_dim        = "\033[22m"
RESET_underlined = "\033[24m"
RESET_reverese   = "\033[27m"
RESET_hidden     = "\033[28m"