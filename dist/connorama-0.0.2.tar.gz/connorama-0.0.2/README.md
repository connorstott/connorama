## Connorama

colours for python terminal